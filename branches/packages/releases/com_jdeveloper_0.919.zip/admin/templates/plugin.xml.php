
<install version="1.5" type="plugin" group="<?php print strtolower($group) ?>">
	<name><?php print ucfirst($group) ?> - <?php print ucfirst($name) ?></name>
	<author></author>
	<creationDate></creationDate>
	<copyright></copyright>
	<license>http://www.gnu.org/licenses/gpl-2.0.html GNU/GPL</license>
	<authorEmail></authorEmail>
	<authorUrl></authorUrl>
	<version></version>
	<description></description>
	<params/>
</install>
