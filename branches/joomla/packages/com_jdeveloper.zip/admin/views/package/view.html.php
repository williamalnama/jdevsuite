<?php
defined('_JEXEC') or die('Restricted access');
class ViewPackage extends ComponentView
{
	
	public function initializeLayout()
	{
		
	}
	
	
}