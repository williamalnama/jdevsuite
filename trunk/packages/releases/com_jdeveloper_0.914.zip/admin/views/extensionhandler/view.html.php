<?php
defined('_JEXEC') or die('Restricted access');
class ViewExtensionHandler extends ComponentView
{
	
	public function initializeLayout()
	{
		
		
	}
	
	
}