<?php
defined('_JEXEC') or die('Restricted access');
class ViewConfig extends ComponentView
{
	
	public function initializeLayout()
	{
		
		
	}
	
	
}