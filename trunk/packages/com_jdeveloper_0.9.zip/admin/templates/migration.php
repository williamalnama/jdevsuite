class <?php print $migrationClassName ?>Migration
{


	public function up()
	{
				
		
	}
	public function down()
	{
		
		
	}

}