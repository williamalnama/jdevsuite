

jimport('joomla.plugin.plugin');

/**
 * @author		
 * @package		Joomla
 * @subpackage	
 * @since 		1.5
 */
class plg<?php print $groupName.$className?> extends JPlugin {



}