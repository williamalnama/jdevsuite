<?php

class JDevControllerAbout  extends ComponentController
{	



}
?>