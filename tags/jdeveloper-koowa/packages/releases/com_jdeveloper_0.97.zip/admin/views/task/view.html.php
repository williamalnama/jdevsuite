<?php
defined('_JEXEC') or die('Restricted access');
class ViewTask extends ComponentView
{
	
	public function initializeLayout()
	{
		
	}
	
	
}