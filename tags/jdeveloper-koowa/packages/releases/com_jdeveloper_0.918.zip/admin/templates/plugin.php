

jimport('joomla.plugin.plugin');

/**
 * @author		
 * @package		Joomla
 * @subpackage	
 * @since 		1.5
 */
class plg<?php print ucfirst($group)?><?php print ucfirst(preg_replace('/_/','',$name))?> extends JPlugin {



}