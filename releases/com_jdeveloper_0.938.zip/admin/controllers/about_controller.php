<?php
defined('_JEXEC') or die('Restricted access');
class ControllerAbout  extends ComponentController
{	



}
?>