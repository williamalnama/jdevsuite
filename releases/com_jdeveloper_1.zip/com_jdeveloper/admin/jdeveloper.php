<?php 
defined('_JEXEC') or die('Restricted access');

require 'updater.php';

$updater = new Updater();

if ( $updater->newVersionAvailable() ) {
	print $updater->getLatestVersion();
	$updater->updateToLatest();
}
require 'core'.DS.'dispatcher.php';