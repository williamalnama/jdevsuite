<?php 
defined('_JEXEC') or die('Restricted access');

require 'core'.DS.'dispatcher.php';