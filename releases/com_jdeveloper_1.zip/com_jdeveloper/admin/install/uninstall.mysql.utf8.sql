DROP TABLE IF EXISTS `#__jdevsuite_schema_info`;
