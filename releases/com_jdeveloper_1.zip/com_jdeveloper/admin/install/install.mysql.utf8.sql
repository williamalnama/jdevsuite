CREATE TABLE IF NOT EXISTS `#__jdevsuite_schema_info` (

	`version`			INT(11) NOT NULL DEFAULT 0,
	
	PRIMARY KEY (`id`)
	
) ENGINE=MyISAM CHARACTER SET `utf8` COLLATE `utf8_general_ci`;

