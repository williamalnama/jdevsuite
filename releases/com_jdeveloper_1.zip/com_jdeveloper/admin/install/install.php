<?php
/**
 * @version		$Id:rubberdoc.install.php 51 2007-10-18 12:35:24Z rmdstudio $
 * @package		eblast
 * @copyright	Copyright (C) 2007 - 2008 rmd Studio Inc. All rights reserved.
 * @license		http://www.gnu.org/copyleft/gpl.html GNU/GPLv2
 * @author		Rastin Mehr <rastin@rmdstudio.com>
 */

// no direct access
defined('_JEXEC') or die('Restricted access');