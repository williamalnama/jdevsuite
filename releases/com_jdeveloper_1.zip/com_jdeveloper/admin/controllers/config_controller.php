<?php
defined('_JEXEC') or die('Restricted access');
class ControllerConfig  extends ComponentController
{	
	public function __construct()
	{
		parent::__construct();
		$this->configModel = $this->getModel('config');
		$this->registerTask('setdevfolder','default_');
	}
	public function default_()
	{
		
		if ( !$this->configModel->devFolderExists() )
			JError::raiseNotice(500,jtext::_('You need to create a developer folder'));
		$this->assign(array('config'=>$this->configModel));
		$this->setLayout('default');
				
	}
	public function setDevFolderPosted()
	{
		$dir = trim(JRequest::getVar('dev_dir'));

		if ( !$this->configModel->setDevFolder($dir) )
			JError::raiseNotice(500,$this->configModel->getError());
		else {				
			$this->setRedirect(array('task'=>'default'),'Folder created. Make sure you delete your old folder','message');
			return;
		}
		$this->setRedirect(array('task'=>'default'));
	}
	public function getViewName()
	{
		return 'config';	
	}
	
}