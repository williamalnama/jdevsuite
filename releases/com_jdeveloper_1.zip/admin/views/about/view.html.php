<?php
// no direct access
defined('_JEXEC') or die('Restricted access');

class eblastViewAbout extends JView {}