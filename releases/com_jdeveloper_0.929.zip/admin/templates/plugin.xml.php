
<install version="1.5" type="plugin" group="<?php print strtolower($groupName) ?>">
	<name><?php print $groupName ?> - <?php print $humanName ?></name>
	<author></author>
	<creationDate><?php print $creationDate ?></creationDate>
	<copyright></copyright>
	<license>http://www.gnu.org/licenses/gpl-2.0.html GNU/GPL</license>
	<authorEmail></authorEmail>
	<authorUrl></authorUrl>
	<version></version>
	<description></description>
	<files>
		<filename plugin="<?php print $pluginName ?>"><?php print $pluginName ?>.php</filename>
	</files>	
	<params/>
</install>
